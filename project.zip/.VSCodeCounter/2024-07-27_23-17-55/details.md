# Details

Date : 2024-07-27 23:17:55

Directory /home/chang/medicine-donation-and-recycling

Total : 5 files,  253 codes, 91 comments, 62 blanks, all 406 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [.prettierrc](/.prettierrc) | json | 3 | 0 | 1 | 4 |
| [contracts/GovernmentChain.sol](/contracts/GovernmentChain.sol) | Solidity | 71 | 20 | 16 | 107 |
| [contracts/LogisticsChain.sol](/contracts/LogisticsChain.sol) | Solidity | 75 | 24 | 16 | 115 |
| [contracts/RelayChain.sol](/contracts/RelayChain.sol) | Solidity | 29 | 21 | 14 | 64 |
| [contracts/UserChain.sol](/contracts/UserChain.sol) | Solidity | 75 | 26 | 15 | 116 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)