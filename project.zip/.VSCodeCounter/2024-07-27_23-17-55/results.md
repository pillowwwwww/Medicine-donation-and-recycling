# Summary

Date : 2024-07-27 23:17:55

Directory /home/chang/medicine-donation-and-recycling

Total : 5 files,  253 codes, 91 comments, 62 blanks, all 406 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Solidity | 4 | 250 | 91 | 61 | 402 |
| json | 1 | 3 | 0 | 1 | 4 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 5 | 253 | 91 | 62 | 406 |
| . (Files) | 1 | 3 | 0 | 1 | 4 |
| contracts | 4 | 250 | 91 | 61 | 402 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)